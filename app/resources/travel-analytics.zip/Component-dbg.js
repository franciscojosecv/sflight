sap.ui.define(["sap/fe/core/AppComponent"], function (Component) {
  "use strict";
  return Component.extend("sap.fe.cap.travel_analytics.Component", {
    metadata: { manifest: "json" },
  });
});
