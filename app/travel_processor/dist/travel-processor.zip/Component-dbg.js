sap.ui.define(["sap/fe/core/AppComponent"], function (AppComponent) {
  "use strict";
  return AppComponent.extend("sap.fe.cap.travel.Component", {
    metadata: { manifest: "json" },
  });
});
